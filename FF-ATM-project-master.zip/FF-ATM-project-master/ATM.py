import math
import random


class Account:
    '''Fields: Name(Str), Pin(Nat), Cash(anyof Nat Float)'''
    
    def __init__(self,name,pin,cash):
        self.name = name
        self.pin = pin
        self.cash = cash
    def __eq__(self, other):
        print(isinstance(other, Account) and self.pin == other.pin)

listacc = []
##################################################  
def createnew():
    uname = input("Enter your name: ")
    upin = random.randint(1000,9999)
    output_file = open("pininfo.txt", "w")
    output_file.write(uname+" pin: "+str(upin)+".")
    output_file.close()
    print()
    print()
    print()
    print("Visit the ATM customer service to retrieve pin")
    print()
    print()
    print()    
    for acc in listacc:
        if acc.pin == upin:
            print()
            print()
            print()            
            print("pin taken, redirecting you to Home...")
            return
    ucash = float(input("Enter inital deposit: $"))
    user = Account(uname, upin, ucash)
    listacc.append(user)
    print()
    print()
    print()    
    print("Account created")
##################################################  
def ATM():
    print("Welcome to the ATM")
    print("Enter one of the options below to continue")
    print("1 - create new user")
    print("2 - login")
    choice = input("Enter your option: ")
##################################################      
    if choice == "1":
        createnew()
        print()
        print()
        print()
        print()        
        print(listacc)
        ATM()
##################################################   
    if choice == "2":
            print()
            print()
            print()            
            pin = int(input("Enter pin: "))
            for acc in listacc:
                if acc.pin == pin:
                    print()
                    print()
                    print()
                    print()                    
                    print("Logged in")
                    
                    boolmain = False
                    while boolmain == False:
                        print("What would you like to do today? : ")
                        print("w - withdraw")
                        print("d - deposit")
                        print("c - check balance")
                        print("l - logout")
                        choice2 = input("Enter your option: ")
                
                        if choice2 == 'w':
                            boola = False      
                            while boola == False:
                                wamt = float(input("How much would you like to withdraw: $"))
                                if wamt > acc.cash:
                                    print()
                                    print()
                                    print()
                                    print()                                    
                                    print("Not enough cash try again")
                                    print()
                                    print()
                                    print()                                    
                                else:
                                    acc.cash = acc.cash - wamt
                                    print()
                                    print()
                                    print()
                                    print()                                    
                                    print("Withdraw Succesful, sending you back to login")
                                    print()
                                    print()
                                    print()                                    
                                    boola = True
                            
                            
                        elif choice2 == 'd':
                            boolb = False
                            while boolb == False:
                                damt = float(input("How much would you like to Deposit: $"))
                                acc.cash = acc.cash + damt
                                print()
                                print()
                                print()                                
                                print("Deposit Succesful, sending you back to login")
                                print()
                                print()
                                print()                                
                                boolb = True
                
                        elif choice2 == "c":
                            print()
                            print()
                            print()
                            print("Current account balance is: $"+str(acc.cash))
                            print()
                            print()
                            print()                            
                        elif choice2 == "l":
                            boolmain = True
                            print()
                            print()
                            print()
                            print("Logged out, returning to Home...")
                            print()
                            print()
                            print()                            
                            ATM()
            print()
            print()
            print()
            print("Pin doesn't exist, redirecting you to Home...")
            print()
            print()
            print()            
            ATM()
##################################################  
 
    if choice != "1" or choice != "2":
        print()
        print()
        print()        
        print("Enter a valid option, redirecting you to Home...")
        print()
        print()
        print()        
        ATM()

                    
            
                    
                                  
                
                    
                
                
            

                
    
    
  

        
        

    
    


    
    
    
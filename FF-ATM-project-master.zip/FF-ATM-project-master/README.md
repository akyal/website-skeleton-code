# FF-ATM-project
Fully functional ATM machine written on Python Code/version 3.6.0/WingIDE

The code simulates a ATM machine with the added option of creating
a new personal bank account where a randomly generated pin password will be
written to a text file for a more realistic/secure simulation. 
